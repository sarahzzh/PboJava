/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Barang;

/**
 *
 * @author C-15
 */

class Mobil{
    private String merk;
    private String model;
    private int tahun;
    private double harga;
    
    public Mobil (String merk, String model, int tahun, double harga){
        this.merk = merk;
        this.model = model;
        this.tahun = tahun;
        this.harga = harga;
    }
    
    public String getMerk(){
        return merk;
    }
    public void setMerk (String merk){
        this.merk = merk;
    }
    public String getModel(){
        return model;
    }
    public void setModel (String model){
        this.model = model;
    }
    public int getTahun(){
        return tahun;
    }
    public void setTahun(int tahun){
        this.tahun = tahun;
    }
    public double getHarga(){
        return harga;
    }
    public void setHarga (double harga){
        this.harga = harga;
    }
}