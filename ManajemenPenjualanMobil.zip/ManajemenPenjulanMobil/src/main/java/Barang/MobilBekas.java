/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Barang;

/**
 *
 * @author C-15
 */
class MobilBekas extends Mobil {
    private int kilometer;
    public MobilBekas(String merk, String model, int tahun, double harga, int kilometer){
        super(merk, model, tahun, harga);
        this.kilometer = kilometer;
    }
    
    public int getKilometer(){
        return kilometer;
    }
    
    public void setKilometer (int kilometer){
        this.kilometer = kilometer;
    }
}
