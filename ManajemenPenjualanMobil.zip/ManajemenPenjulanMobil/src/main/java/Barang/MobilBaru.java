/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Barang;



/**
 *
 * @author C-15
 */
class MobilBaru extends Mobil{
    public MobilBaru (String merk, String model, int tahun, double harga){
        super(merk , model , tahun, harga);
    }
}
